"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const BaseClasses_1 = require("@spt/models/enums/BaseClasses");
const config_json_1 = __importDefault(require("../config/config.json"));
const LogTextColor_1 = require("@spt/models/spt/logging/LogTextColor");
class Lkm {
    postDBLoad(container) {
        var _a, _b, _c;
        const databaseServer = container.resolve("DatabaseServer");
        const logger = container.resolve("WinstonLogger");
        const itemHelper = container.resolve("ItemHelper");
        const database = databaseServer.getTables();
        const locations = database.locations;
        let count = 0;
        let looseCount = 0;
        let looseKCount = 0;
        for (const mapId in locations) {
            const staticLoot = (_a = locations[mapId]) === null || _a === void 0 ? void 0 : _a.staticLoot;
            if (staticLoot) {
                count += this.updateStaticLoot(staticLoot, itemHelper);
            }
            const spawnPoints = (_c = (_b = locations[mapId]) === null || _b === void 0 ? void 0 : _b.looseLoot) === null || _c === void 0 ? void 0 : _c.spawnpoints;
            if (spawnPoints) {
                const { looseCount: lc, looseKCount: lkc } = this.updateLocationSpawnPoints(spawnPoints, itemHelper);
                looseCount += lc;
                looseKCount += lkc;
            }
        }
        this.logResults(logger, count, looseCount, looseKCount);
    }
    updateLocationSpawnPoints(spawnPoints, itemHelper) {
        let looseCount = 0;
        let looseKCount = 0;
        for (const spawnPoint of spawnPoints) {
            for (const item of spawnPoint.template.Items) {
                if (itemHelper.isOfBaseclass(item._tpl, BaseClasses_1.BaseClasses.KEY_MECHANICAL)) {
                    looseCount += this.updateKeyProbability(spawnPoint, item);
                }
                else if (itemHelper.isOfBaseclass(item._tpl, BaseClasses_1.BaseClasses.KEYCARD) && config_json_1.default.AlterKeyCardProbability) {
                    looseKCount += this.updateKeycardProbability(spawnPoint, item);
                }
            }
        }
        return { looseCount, looseKCount };
    }
    updateKeyProbability(spawnPoint, item) {
        const matchingItem = spawnPoint.itemDistribution.find(x => x.composedKey.key === item._id);
        if (matchingItem) {
            if (spawnPoint.probability < config_json_1.default.LooseKeyPileProbability) {
                spawnPoint.probability = config_json_1.default.LooseKeyPileProbability;
            }
            if (matchingItem.relativeProbability < config_json_1.default.relativeProbabilityThreshold) {
                matchingItem.relativeProbability *= config_json_1.default.relativeProbabilitymultiplier;
            }
            return 1;
        }
        return 0;
    }
    updateKeycardProbability(spawnPoint, item) {
        const matchingItem = spawnPoint.itemDistribution.find(x => x.composedKey.key === item._id);
        if (matchingItem) {
            if (spawnPoint.probability < config_json_1.default.LooseKeycardProbability) {
                spawnPoint.probability = config_json_1.default.LooseKeycardProbability;
                return 1;
            }
        }
        return 0;
    }
    updateStaticLoot(staticLoot, itemHelper) {
        var _a;
        let count = 0;
        for (const staticName in staticLoot) {
            const staticy = (_a = staticLoot[staticName]) === null || _a === void 0 ? void 0 : _a.itemDistribution;
            if (!staticy)
                continue;
            if (staticName === Lkm.DRAWER_ID) {
                count += this.updateStaticItemDistribution(staticy, itemHelper, config_json_1.default.drawerStaticRelativeProbability);
            }
            else if (staticName === Lkm.JACKET_ID) {
                count += this.updateStaticItemDistribution(staticy, itemHelper, config_json_1.default.jacketStaticRelativeProbability);
            }
        }
        return count;
    }
    updateStaticItemDistribution(staticy, itemHelper, probability) {
        let count = 0;
        for (const itemDistribution of staticy) {
            if (itemHelper.isOfBaseclass(itemDistribution.tpl, BaseClasses_1.BaseClasses.KEY_MECHANICAL)) {
                const matchingItem = staticy.find(s => s.tpl === itemDistribution.tpl);
                if (matchingItem && itemDistribution.relativeProbability < probability) {
                    itemDistribution.relativeProbability = probability;
                    count++;
                }
            }
        }
        return count;
    }
    logResults(logger, staticCount, looseCount, looseKCount) {
        if (looseCount === 0 && looseKCount === 0) {
            logger.logWithColor("No Items modified. Check config parameters", LogTextColor_1.LogTextColor.RED);
        }
        else {
            logger.logWithColor(`Finished Altering ${staticCount} static loot positions`, LogTextColor_1.LogTextColor.GREEN);
            logger.logWithColor(`Finished Altering ${looseCount} looseloot keys and ${looseKCount} looseloot keycards`, LogTextColor_1.LogTextColor.GREEN);
        }
    }
}
Lkm.DRAWER_ID = "578f87b7245977356274f2cd";
Lkm.JACKET_ID = "578f8778245977358849a9b5";
module.exports = { mod: new Lkm() };