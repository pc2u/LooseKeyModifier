import { ItemHelper } from "@spt-aki/helpers/ItemHelper";
import { Spawnpoint } from "@spt-aki/models/eft/common/ILooseLoot";
import { ItemDistribution } from "@spt-aki/models/eft/common/tables/ILootBase";
import { BaseClasses } from "@spt-aki/models/enums/BaseClasses";
import type { IPostDBLoadMod } from "@spt-aki/models/external/IPostDBLoadMod";
import { DatabaseServer } from "@spt-aki/servers/DatabaseServer";
import { DependencyContainer } from "tsyringe";

import config from "../config/config.json";

class Lkm implements IPostDBLoadMod
{
    public postDBLoad(container: DependencyContainer): void 
    {
        const databaseServer: DatabaseServer = container.resolve<DatabaseServer>("DatabaseServer");
        const itemHelper = container.resolve<ItemHelper>("ItemHelper");
        const database = databaseServer.getTables();
        const locations = database.locations;
        const staticLoot = database.loot.staticLoot;
        
        let count = 0;
        let looseCount = 0;
        let looseKCount = 0;


        for (const staticName in staticLoot)
        {
            const staticy: ItemDistribution[] = staticLoot[staticName]?.itemDistribution;
            if (!staticy)
            {
                continue;
            }
            if (staticName === "578f87b7245977356274f2cd") // Drawer
            {
                for (const itemDistribution of staticy)
                {
                    if (itemHelper.isOfBaseclass(itemDistribution.tpl, BaseClasses.KEY_MECHANICAL))
                    {
                        const matchingItem = staticy.find(s => s.tpl === itemDistribution.tpl);
                        if (matchingItem)
                        {
                            if (itemDistribution.relativeProbability < config.drawerStaticRelativeProbability)
                            {
                                // By Default this is based of the Yotota Key and been divided by 2
                                itemDistribution.relativeProbability = config.drawerStaticRelativeProbability;
                                count++;
                            }
                        } 
                    }
                }
            }
            if (staticName === "578f8778245977358849a9b5") // Jackets
            {
                for (const itemDistribution of staticy)
                {
                    if (itemHelper.isOfBaseclass(itemDistribution.tpl, BaseClasses.KEY_MECHANICAL))
                    {
                        const matchingItem = staticy.find(s => s.tpl === itemDistribution.tpl);
                        if (matchingItem)
                        {
                            if (itemDistribution.relativeProbability < (config.jacketStaticRelativeProbability))
                            {
                                // By Default this is based of the Yotota Key and been divided by 4
                                itemDistribution.relativeProbability = (config.jacketStaticRelativeProbability);
                                count++;
                            }
                        } 
                    }
                }
            }
        }
        console.log(`Finished Altering ${count} Container Keys `);
        
        for (const mapId in locations) 
        {
            const spawnPoints: Spawnpoint[] = locations[mapId]?.looseLoot?.spawnpoints;
            if (!spawnPoints) 
            {
                continue;
            }
            for (const spawnPoint of spawnPoints) 
            {
                for (const item of spawnPoint.template.Items) 
                {
                    if (itemHelper.isOfBaseclass(item._tpl, BaseClasses.KEY_MECHANICAL))
                    {
                        const matchingItem = spawnPoint.itemDistribution.find(x => x.composedKey.key === item._id);
                        if (matchingItem) 
                        {
                            if (spawnPoint.probability < config.LooseKeyPileProbability) 
                            {
                                spawnPoint.probability = config.LooseKeyPileProbability;
                                
                            }
                            if (matchingItem.relativeProbability < config.relativeProbabilityThreshold) 
                            {
                                matchingItem.relativeProbability *= config.relativeProbabilitymultiplier;
                            }
                            looseCount++;
                        }
                    }
                    else
                    {
                        // Any loot changes wont modify items inside of loot.json(Added Keycards from SPT Team)
                        if (itemHelper.isOfBaseclass(item._tpl, BaseClasses.KEYCARD) && config.AlterKeyCardProbability == true)
                        {
                            const matchingItem = spawnPoint.itemDistribution.find(x => x.composedKey.key === item._id);
                            if (matchingItem) 
                            {
                                if (spawnPoint.probability < config.LooseKeycardProbability) 
                                {
                                    spawnPoint.probability = config.LooseKeycardProbability;
                                    looseKCount++;
                                }
                            }
                        }
                    }
                }
            }
        }
        if (looseCount === 0 && looseKCount === 0)
        {
            console.log("No Items modified. Check config parameters");
        }
        else
            console.log(`Finished Altering ${looseCount} LooseLoot Keys and ${looseKCount} LooseLoot Keycards. Lkm`);
    }
}
module.exports = { mod: new Lkm() };